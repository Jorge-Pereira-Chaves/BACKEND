# API REST de Livros

API REST desenvolvida em Java utilizando Spring Boot para gerenciamento de livros.

Os dados são armazenados em memória, sem banco de dados.

## Tecnologias

- Java 17
- Spring Boot
- Maven
- Spring Web
- API REST
- JSON

## Funcionalidades

- Cadastrar livros
- Consultar todos os livros
- Consultar livro por ID
- Atualizar livro
- Excluir livro

## Como executar

Na pasta principal do projeto:

```bash
mvn spring-boot:run
```

A aplicação será iniciada na porta 8080.

## Endpoints

### Listar livros

```http
GET /livros
```

`http://localhost:8080/livros`

### Buscar livro por ID

```http
GET /livros/{id}
```

Exemplo:

`http://localhost:8080/livros/1`

### Cadastrar livro

```http
POST /livros
```

JSON:

```json
{
    "titulo": "Harry Potter e a Pedra Filosofal",
    "autor": "J. K. Rowling",
    "genero": "Fantasia",
    "anoPublicacao": 1997
}
```

### Atualizar livro

```http
PUT /livros/{id}
```

JSON:

```json
{
    "titulo": "Dom Casmurro - Edição Atualizada",
    "autor": "Machado de Assis",
    "genero": "Romance",
    "anoPublicacao": 1899
}
```

### Excluir livro

```http
DELETE /livros/{id}
```

Como os dados são armazenados em memória, eles são perdidos quando a aplicação é encerrada.
