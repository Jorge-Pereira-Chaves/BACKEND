package com.exemplo.apilivros.service;

import com.exemplo.apilivros.model.Livro;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

@Service
public class LivroService {

    private final List<Livro> livros = new ArrayList<>();
    private final AtomicLong contador = new AtomicLong(1);

    public LivroService() {
        livros.add(new Livro(
                contador.getAndIncrement(),
                "Dom Casmurro",
                "Machado de Assis",
                "Romance",
                1899
        ));

        livros.add(new Livro(
                contador.getAndIncrement(),
                "O Hobbit",
                "J. R. R. Tolkien",
                "Fantasia",
                1937
        ));
    }

    public List<Livro> listarTodos() {
        return livros;
    }

    public Livro buscarPorId(Long id) {
        return livros.stream()
                .filter(livro -> livro.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    public Livro cadastrar(Livro livro) {
        livro.setId(contador.getAndIncrement());
        livros.add(livro);
        return livro;
    }

    public Livro atualizar(Long id, Livro livroAtualizado) {
        Livro livro = buscarPorId(id);

        if (livro == null) {
            return null;
        }

        livro.setTitulo(livroAtualizado.getTitulo());
        livro.setAutor(livroAtualizado.getAutor());
        livro.setGenero(livroAtualizado.getGenero());
        livro.setAnoPublicacao(livroAtualizado.getAnoPublicacao());

        return livro;
    }

    public boolean excluir(Long id) {
        Livro livro = buscarPorId(id);

        if (livro == null) {
            return false;
        }

        livros.remove(livro);
        return true;
    }
}
