package com.exemplo.apilivros;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiLivrosApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApiLivrosApplication.class, args);
    }
}
