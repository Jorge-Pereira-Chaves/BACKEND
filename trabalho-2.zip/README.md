# API Livros - Trabalho 2

API REST desenvolvida com Java, Spring Boot, Spring Data JPA e PostgreSQL.

## Configuração do PostgreSQL

O projeto está configurado para:

- Banco: api_livros
- Usuário: postgres
- Senha: admin1234
- Porta: 5432

Primeiro crie o banco `api_livros` no PostgreSQL.

Depois abra o projeto no IntelliJ, Eclipse ou VS Code e execute a classe:

`ApiLivrosApplication.java`

O Hibernate criará a tabela `livro` automaticamente.

## Rotas

POST /livros

GET /livros

GET /livros/{id}

PUT /livros/{id}

DELETE /livros/{id}

## Filtros combináveis

GET /livros?titulo=java

GET /livros?genero=ficcao

GET /livros?ano=2020

Também é possível combinar:

GET /livros?titulo=java&genero=programacao&ano=2020

## JSON para cadastrar

{
  "titulo": "Java: Como Programar",
  "autor": "Deitel",
  "genero": "Programação",
  "anoPublicacao": 2020
}

O ID não deve ser enviado no POST. Ele é gerado automaticamente pelo PostgreSQL.

## Consulta no PostgreSQL

Após cadastrar livros pela API, execute:

SELECT * FROM livro;

## Dependências

- Spring Web
- Spring Data JPA
- PostgreSQL Driver
