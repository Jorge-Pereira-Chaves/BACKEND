package com.exemplo.apilivros.repository;

import com.exemplo.apilivros.model.Livro;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface LivroRepository extends JpaRepository<Livro, Long> {

    @Query("SELECT l FROM Livro l " +
           "WHERE (:titulo IS NULL OR LOWER(l.titulo) LIKE LOWER(CONCAT('%', :titulo, '%'))) " +
           "AND (:genero IS NULL OR LOWER(l.genero) LIKE LOWER(CONCAT('%', :genero, '%'))) " +
           "AND (:ano IS NULL OR l.anoPublicacao = :ano)")
    List<Livro> buscarComFiltros(
            @Param("titulo") String titulo,
            @Param("genero") String genero,
            @Param("ano") Integer ano
    );
}
