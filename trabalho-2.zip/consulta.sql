SELECT * FROM livro;
